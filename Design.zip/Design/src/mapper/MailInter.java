package mapper;

import java.sql.SQLException;
import java.util.List;

import POJOs.Mail;
import POJOs.RubMail;

public interface MailInter {
	public void mailSend(Mail mail) throws Exception;
	public List<Mail> recievedmailShow(String recieveuser) throws Exception;
	public List<Mail> sentmailShow(String senduser) throws Exception;
	public List<Mail> All(String senduser) throws Exception;
	public void MailDelete(String senduser, String date) throws Exception;
	public List<RubMail> DeletedMailFind(String senduser) throws Exception;
	public void MailRestore(String user, String date) throws Exception;
	public void setMailPwd(String user,String date,String pwd) throws SQLException;
	public String getMailPwd(String user,String date) throws SQLException;
}
