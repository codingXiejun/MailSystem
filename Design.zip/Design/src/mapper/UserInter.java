package mapper;

import POJOs.Account;
import POJOs.User;

//����UserDao�ӿ�
public interface UserInter {
	public void AccountCreate(Account a)throws Exception;
	public void UserCreate(User user) throws Exception;
	public User ShowAll(String email) throws Exception;
	public void update(User user) throws Exception;
	public boolean recieveuserconfirm(String recieveuser) throws Exception;
}
