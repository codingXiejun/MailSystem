package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import POJOs.Mail;
import POJOs.RubMail;
import mapper.MailInter;
import util.JdbcUtil;

public class MailDao implements MailInter{
	private static Connection conn = null;
	private static PreparedStatement ps = null;
	private static ResultSet rs = null;
	
	public void mailSend(Mail mail) throws Exception {// �����ʼ���mail���ݿ�
		try {
			conn = JdbcUtil.getConnection();
			String sql = "insert into mail values(?,?,?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, mail.getSenduser());
			ps.setString(2, mail.getRecieveuser());
			ps.setString(3, mail.getDate());
			ps.setString(4, mail.getTheme());
			ps.setString(5, mail.getContent());
			ps.executeUpdate();
		} finally {
			JdbcUtil.free(null, ps, conn);
		}
	}

	public List<Mail> recievedmailShow(String recieveuser) throws Exception {// �û��ռ���
		Mail m = null;
		List<Mail> list = new ArrayList<Mail>();
		try {
			conn = JdbcUtil.getConnection();
			String sql = "select * from mail where recieveuser='" + recieveuser + "'";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				m = new Mail();
				m.setSenduser(rs.getString(1));
				m.setRecieveuser(rs.getString(2));
				m.setDate(rs.getString(3));
				m.setTheme(rs.getString(4));
				m.setContent(rs.getString(5));
				list.add(m);
			}
		} finally {
			JdbcUtil.free(null, ps, conn);
		}
		return list;
	}

	public List<Mail> sentmailShow(String senduser) throws Exception {// �û�������
		Mail m = null;
		List<Mail> list = new ArrayList<Mail>();
		try {
			conn = JdbcUtil.getConnection();
			String sql = "select * from mail where senduser='" + senduser + "'";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				m = new Mail();
				m.setSenduser(rs.getString(1));
				m.setRecieveuser(rs.getString(2));
				m.setDate(rs.getString(3));
				m.setTheme(rs.getString(4));
				m.setContent(rs.getString(5));
				list.add(m);
			}
		} finally {
			JdbcUtil.free(null, ps, conn);
		}
		return list;
	}

	public List<Mail> All(String senduser) throws Exception {// ��ʾ�������û��йص��ʼ�
		Mail m = null;
		List<Mail> list = new ArrayList<Mail>();
		try {
			conn = JdbcUtil.getConnection();
			String sql = "select * from mail where senduser='" + senduser + "' or recieveuser='" + senduser + "'";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				m = new Mail();
				m.setSenduser(rs.getString(1));
				m.setRecieveuser(rs.getString(2));
				m.setDate(rs.getString(3));
				m.setTheme(rs.getString(4));
				m.setContent(rs.getString(5));
				list.add(m);
			}
		} finally {
			JdbcUtil.free(null, ps, conn);
		}
		return list;
	}

	public void MailDelete(String senduser, String date) throws Exception {// �ʼ�ɾ��
		try {
			conn = JdbcUtil.getConnection();
			String sql = "insert into rub values(?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, senduser);
			ps.setString(2, date);
			int n = ps.executeUpdate();
		} finally {
			JdbcUtil.free(null, ps, conn);
		}
	}

	public List<RubMail> DeletedMailFind(String senduser) throws Exception {// ���и��û�ɾ�����ʼ�
		List<RubMail> list = new ArrayList<RubMail>();
		try {
			conn = JdbcUtil.getConnection();
			String sql = "select * from rub where user='" + senduser + "'";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				RubMail mail = new RubMail();
				mail.setUser(rs.getString(1));
				mail.setDate(rs.getString(2));
				list.add(mail);
			}
		} finally {
			JdbcUtil.free(null, ps, conn);
		}
		return list;
	}

	public void MailRestore(String user, String date) throws Exception {//��ԭ�ʼ�
		try {
			String sql = "delete from rub where user='" + user + "' and date='" + date + "'";
			conn = JdbcUtil.getConnection();
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		} finally {
			JdbcUtil.free(null, ps, conn);
		}
	}
	
	public void setMailPwd(String user,String date,String pwd) throws SQLException {
		try {
			String sql = "update mail set pwd="+pwd+"where user="+user+"and date="+date;
			conn = JdbcUtil.getConnection();
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
		}finally {
			JdbcUtil.free(null, ps, conn);
		}
	}
	
	public String getMailPwd(String user,String date) throws SQLException{
		try {
			String pwd = null;
			String sql = "select pwd from mail where senduser=? and date=?";
			conn = JdbcUtil.getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, user);
			ps.setString(2, date);
			rs=ps.executeQuery();
			if(rs.next())
				pwd=rs.getString(1);
			return pwd;
		}finally {
			JdbcUtil.free(null, ps, conn);
		}
		
	}
}
