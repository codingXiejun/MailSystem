package Dao;

import java.sql.*;

import POJOs.Account;
import POJOs.User;
import mapper.UserInter;
import util.JdbcUtil;

public class UserDao implements UserInter {
	public void AccountCreate(Account a) throws Exception {// �˻����
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = JdbcUtil.getConnection();
			String sql = "insert into Account values(?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, a.getEmail());
			ps.setString(2, a.getTel());
			ps.setString(3, a.getPassword());
			int n = ps.executeUpdate();
		} finally {
			JdbcUtil.free(null, ps, conn);
		}
	}

	public void UserCreate(User user) throws Exception {// ��Ϣע��
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = JdbcUtil.getConnection();
			String sql = "insert into user values(?,?,?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getEmail());
			ps.setString(2, user.getName());
			ps.setString(3, user.getSex());
			ps.setInt(4, user.getAge());
			ps.setString(5, user.getTel());
			int n = ps.executeUpdate();
		} finally {
			JdbcUtil.free(null, ps, conn);
		}
	}

	public User ShowAll(String email) throws Exception {// ��ʾ�û�������Ϣ
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		User user = new User();
		try {
			conn = JdbcUtil.getConnection();
			String sql = "select * from user where email='" + email + "'";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			if (rs.next()) {
				user.setEmail(rs.getString(1));
				user.setName(rs.getString(2));
				user.setSex(rs.getString(3));
				user.setAge(rs.getInt(4));
				user.setTel(rs.getString(5));
			}
		} finally {
			JdbcUtil.free(null, ps, conn);
		}
		return user;
	}

	public void update(User user) throws Exception {// �޸��û���Ϣ
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = JdbcUtil.getConnection();
			String sql = "update user set name=?,sex=?,age=?,tel=? where email=? ";
			ps = conn.prepareStatement(sql);
			ps.setString(1, user.getName());
			ps.setString(2, user.getSex());
			ps.setInt(3, user.getAge());
			ps.setString(4, user.getTel());
			ps.setString(5, user.getEmail());
			int n = ps.executeUpdate();
		} finally {
			JdbcUtil.free(null, ps, conn);
		}
	}

	public boolean recieveuserconfirm(String recieveuser) throws Exception {// ����ռ����Ƿ����
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean b = true;
		try {
			conn = JdbcUtil.getConnection();
			String sql = "select * from account where email='" + recieveuser + "'";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			if (rs.next()) {
				b = false;
			}
		} finally {
			JdbcUtil.free(null, ps, conn);
		}
		return b;
	}
}
