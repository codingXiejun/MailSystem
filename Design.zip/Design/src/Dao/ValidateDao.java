package Dao;

import java.sql.*;

import POJOs.Account;
import util.JdbcUtil;

public class ValidateDao {
	public boolean val(Account a) throws Exception{
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		boolean res=false;
		try {
			conn=JdbcUtil.getConnection();
			String sql="select * from account where email='"+a.getEmail()+"' and password='"+a.getPassword()+"'";
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			if(rs.next()) {
				res=true;
			}
		}finally {
			JdbcUtil.free(null, ps, conn);
		}
		return res;
	}
}
