package POJOs;

public class Mail {
	private String senduser,recieveuser,date,theme,content;	
	
	public String getSenduser() {
		return senduser;
	}

	public void setSenduser(String senduser) {
		this.senduser = senduser;
	}

	public String getRecieveuser() {
		return recieveuser;
	}

	public void setRecieveuser(String recieveuser) {
		this.recieveuser = recieveuser;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTheme() {
		return theme;
	}

	public void setTheme(String theme) {
		this.theme = theme;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
}
