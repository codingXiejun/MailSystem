package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.xml.internal.serialize.Printer;

@WebServlet("/Readmail")
public class Readmail extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String senduser=request.getParameter("senduser");
		String recieveuser=request.getParameter("recieveuser");
		String date=request.getParameter("date");
		String theme=request.getParameter("theme");
		String content=request.getParameter("content");
		response.sendRedirect("readmail.jsp?senduser="+senduser+"&recieveuser="+recieveuser+"&date="+date+"&theme="+theme+"&content="+content);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
