package Servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.MailDao;

@WebServlet("/setPwd")
public class setPwd extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public setPwd() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		MailDao md = new MailDao();
		String user = request.getParameter("user");
		String date = request.getParameter("date");
		String pwd = request.getParameter("pwd");
		String x = request.getParameter("x");
		try {
			md.setMailPwd(user, date, pwd);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		response.sendRedirect("choosemail.jsp?x="+x);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
