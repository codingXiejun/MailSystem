/*
 Navicat Premium Data Transfer

 Source Server         : root
 Source Server Type    : MySQL
 Source Server Version : 50717
 Source Host           : localhost:3306
 Source Schema         : design

 Target Server Type    : MySQL
 Target Server Version : 50717
 File Encoding         : 65001

 Date: 23/11/2018 07:33:35
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account`  (
  `email` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `tel` varchar(11) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` varchar(16) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ip` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`email`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES ('test', '11111111111', '111111', '10.250.207.9,10.250.207.91');
INSERT INTO `account` VALUES ('test2', '11111111111', '123456', '10.250.207.91');

-- ----------------------------
-- Table structure for mail
-- ----------------------------
DROP TABLE IF EXISTS `mail`;
CREATE TABLE `mail`  (
  `senduser` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `recieveuser` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `date` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `theme` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `content` varchar(400) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `pwd` varchar(16) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mail
-- ----------------------------
INSERT INTO `mail` VALUES ('test2', 'test', '2018-5-23 12:03:50', '给test', 'test发送给test2', NULL);
INSERT INTO `mail` VALUES ('test', 'test2', '2018-5-29 19:55:30', '给test2', 'test发送给test2', '123');
INSERT INTO `mail` VALUES ('test', 'test2', '2018-5-30 13:01:32', '今天下午两点', '收到请回复', NULL);
INSERT INTO `mail` VALUES ('test2', 'test', '2018-5-30 13:13:46', '今天下午两点', '收到请回复', '233');
INSERT INTO `mail` VALUES ('test', 'test2', '2018-5-30 14:18:52', '今天下午两点', '收到请回复', NULL);
INSERT INTO `mail` VALUES ('test', 'test2', '2018-5-30 14:19:13', '今天下午两点', '收到请回复www', NULL);
INSERT INTO `mail` VALUES ('test2', 'test', '2018-5-30 15:15:40', '加密', '11111', '111');

-- ----------------------------
-- Table structure for rub
-- ----------------------------
DROP TABLE IF EXISTS `rub`;
CREATE TABLE `rub`  (
  `user` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `date` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of rub
-- ----------------------------
INSERT INTO `rub` VALUES ('921361215@qq.com', '2018-5-25 22:20:36');
INSERT INTO `rub` VALUES ('test2', '2018-5-28 10:26:06');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `email` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(8) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `sex` varchar(2) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `age` int(3) NOT NULL,
  `tel` varchar(11) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`email`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('123456abc@qq.com', '啊啊', '男', 11, '11111111111');
INSERT INTO `user` VALUES ('885914459@qq.com', '吴洋洋', '女', 18, '15016096688');
INSERT INTO `user` VALUES ('921361215@qq.com', '谢军', '男', 18, '15621141971');
INSERT INTO `user` VALUES ('9965524583@qq.com', '王枫', '男', 17, '15575537288');
INSERT INTO `user` VALUES ('test', 'test', '男', 100, '11111111111');
INSERT INTO `user` VALUES ('test2', 'test2', '男', 100, '11111111111');
INSERT INTO `user` VALUES ('test3@qq.com', '测试三', '男', 100, '11111111111');

-- ----------------------------
-- Event structure for 1
-- ----------------------------
DROP EVENT IF EXISTS `1`;
delimiter ;;
CREATE EVENT `1`
ON SCHEDULE AT '2017-10-26 23:42:36'
DO select * from account where email='921361215'
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
